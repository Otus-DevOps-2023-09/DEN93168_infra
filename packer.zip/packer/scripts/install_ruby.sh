#!/bin/sh
apt update
apt install -y ruby-full ruby-bundler build-essential
